// db.js — تهيئة قاعدة البيانات SQLite + البيانات الأولية
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

const db = new Database(path.join(__dirname, 'erp.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'cashier', -- admin | cashier
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  price REAL NOT NULL DEFAULT 0,
  stock INTEGER NOT NULL DEFAULT 0,
  min_stock INTEGER NOT NULL DEFAULT 3,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS clients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT DEFAULT '',
  address TEXT DEFAULT '',
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_no TEXT UNIQUE NOT NULL,
  client_id INTEGER REFERENCES clients(id),
  user_id INTEGER REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'completed', -- completed | cancelled
  total REAL NOT NULL DEFAULT 0,
  notes TEXT DEFAULT '',
  created_at TEXT DEFAULT (datetime('now')),
  cancelled_at TEXT,
  cancelled_by INTEGER REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS sale_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id),
  qty INTEGER NOT NULL,
  price REAL NOT NULL -- السعر وقت البيع
);
`);

// ---------- البيانات الأولية (مرة واحدة فقط) ----------
const hasUsers = db.prepare('SELECT COUNT(*) c FROM users').get().c > 0;
if (!hasUsers) {
  const insUser = db.prepare('INSERT INTO users (username, password_hash, role) VALUES (?,?,?)');
  insUser.run('admin', bcrypt.hashSync('admin123', 10), 'admin');
  insUser.run('caissier', bcrypt.hashSync('caissier123', 10), 'cashier');

  const insP = db.prepare('INSERT INTO products (name, price, stock, min_stock) VALUES (?,?,?,?)');
  [['صالون مغربي 7 مقاعد', 12500, 6, 2], ['كنبة زاوية', 8900, 4, 2], ['طاولة وسط', 2400, 12, 3],
   ['خزانة ملابس 3 أبواب', 5600, 5, 2], ['سرير 160 + مرتبة', 4300, 7, 2],
   ['كرسي جلد', 1450, 2, 3], ['مصباح أرضي', 950, 2, 3], ['مرآة مزخرفة', 1100, 9, 3]
  ].forEach(p => insP.run(...p));

  const insC = db.prepare('INSERT INTO clients (name, phone, address) VALUES (?,?,?)');
  [['يوسف العلوي', '0612 34 56 78', 'وجدة'], ['فاطمة الزهراء م.', '0722 33 44 55', 'وجدة'],
   ['محمد بناني', '0655 66 77 88', 'تنجداد'], ['خديجة الإدريسي', '0706 07 78 38', 'بركان']
  ].forEach(c => insC.run(...c));

  // عملية بيع تجريبية كاملة (بفاتورة رقم 1)
  const sale = db.prepare(`INSERT INTO sales (invoice_no, client_id, user_id, status, total, created_at)
    VALUES ('FA-2026-0001', 1, 2, 'completed', 13700, '2026-09-08 11:30:00')`).run();
  const si = db.prepare('INSERT INTO sale_items (sale_id, product_id, qty, price) VALUES (?,?,?,?)');
  si.run(sale.lastInsertRowid, 1, 1, 12500);
  si.run(sale.lastInsertRowid, 8, 1, 1200);
  db.prepare('UPDATE products SET stock = stock - 1 WHERE id IN (1,8)').run();
}

module.exports = db;
