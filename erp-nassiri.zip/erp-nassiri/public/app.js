// app.js — واجهة الـERP (SPA)
const $ = s => document.querySelector(s);
const page = $('#page');
let ME = null, PRODUCTS = [], CLIENTS = [], CART = [];

async function api(path, opts = {}) {
  const r = await fetch('/api' + path, {
    headers: { 'Content-Type': 'application/json' },
    ...opts, body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'وقع خطأ');
  return d;
}
const dh = n => (+n).toLocaleString('fr-FR') + ' DH';
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const today = () => new Date().toISOString().slice(0, 10);
const stChip = s => s === 'completed' ? '<span class="chip c-ok">مكتمل</span>' : '<span class="chip c-bad">ملغي</span>';

// ---------- الجلسة ----------
$('#loginForm').onsubmit = async e => {
  e.preventDefault();
  try {
    ME = await api('/login', { method: 'POST', body: { username: $('#lUser').value, password: $('#lPass').value } });
    boot();
  } catch (e2) { $('#loginErr').textContent = e2.message; }
};
$('#logoutBtn').onclick = async () => { await api('/logout', { method: 'POST' }); location.reload(); };

function boot() {
  $('#loginView').classList.add('hidden');
  $('#app').classList.remove('hidden');
  $('#meName').textContent = ME.username + (ME.role === 'admin' ? ' · مدير' : '');
  if (ME.role === 'admin') $('#navUsers').classList.remove('hidden');
  $('#nav').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    document.querySelectorAll('#nav button').forEach(x => x.classList.toggle('on', x === b));
    location.hash = b.dataset.page;
    render();
  };
  window.onhashchange = render;
  render();
}

async function render() {
  const p = (location.hash || '#dash').slice(1);
  document.querySelectorAll('#nav button').forEach(x => x.classList.toggle('on', x.dataset.page === p));
  try {
    if (p === 'sales') return renderSales();
    if (p === 'newSale') return renderNewSale();
    if (p === 'products') return renderProducts();
    if (p === 'clients') return renderClients();
    if (p === 'reports') return renderReports();
    if (p === 'users' && ME.role === 'admin') return renderUsers();
    renderDash();
  } catch (e) { page.innerHTML = `<div class="empty">${esc(e.message)}</div>`; }
}

// ---------- القيادة ----------
async function renderDash() {
  const [s, low] = [await api('/reports/summary'), null];
  const lowList = s.low;
  page.innerHTML = `
    <div class="grid">
      <div class="kpi"><small>مبيعات اليوم</small><b class="num">${dh(s.today.t)}</b><small>${s.today.c} عملية</small></div>
      <div class="kpi"><small>آخر 7 أيام</small><b class="num">${dh(s.week.t)}</b><small>${s.week.c} عملية</small></div>
      <div class="kpi"><small>هاد الشهر</small><b class="num">${dh(s.month.t)}</b><small>${s.month.c} عملية</small></div>
      <div class="kpi"><small>قيمة المخزون</small><b class="num">${dh(s.stockVal)}</b></div>
    </div>
    <div class="panel">
      <h3>مبيعات آخر 14 يوم</h3>
      ${barChart(s.daily)}
    </div>
    <div class="panel">
      <h3>أفضل المنتوجات</h3>
      ${s.top.length ? `<table><tr><th>المنتوج</th><th>المبيعات</th><th>الكمية</th></tr>${s.top.map(t => `<tr><td>${esc(t.name)}</td><td class="num">${dh(t.t)}</td><td class="num">${t.q}</td></tr>`).join('')}</table>` : '<div class="empty">مازال ماكاينش مبيعات</div>'}
    </div>
    <div class="panel">
      <h3>المخزون القليل ⚠️</h3>
      ${lowList.length ? `<table><tr><th>المنتوج</th><th>باقي</th><th>الحد الأدنى</th></tr>${lowList.map(p => `<tr><td>${esc(p.name)}</td><td><span class="chip c-warn num">${p.stock}</span></td><td class="num">${p.min_stock}</td></tr>`).join('')}</table>` : '<div class="empty">كلشي مزيان</div>'}
    </div>`;
}
function barChart(rows) {
  if (!rows.length) return '<div class="empty">مازال ماكاينش بيانات</div>';
  const W = 640, H = 180, max = Math.max(...rows.map(r => r.t), 1);
  const bw = W / rows.length - 12;
  return `<svg viewBox="0 0 ${W} ${H + 30}" style="width:100%;max-width:720px">
    ${rows.map((r, i) => { const h = Math.round(r.t / max * H); const x = i * (bw + 12);
      return `<rect x="${x}" y="${H - h}" width="${bw}" height="${h}" rx="4" fill="#1a1a1a" opacity="${0.3 + 0.7 * r.t / max}"/>
      <text x="${x + bw / 2}" y="${H - h - 6}" text-anchor="middle" font-size="10" fill="#6b6b6b" class="num">${(r.t / 1000).toFixed(0)}k</text>
      <text x="${x + bw / 2}" y="${H + 16}" text-anchor="middle" font-size="10" fill="#6b6b6b">${r.d.slice(5)}</text>`; }).join('')}
  </svg>`;
}

// ---------- المبيعات ----------
async function renderSales() {
  const sales = await api('/sales');
  page.innerHTML = `
    <h2>المبيعات والفواتير</h2>
    <div class="panel">
      <table>
        <tr><th>الفاتورة</th><th>التاريخ</th><th>الزبون</th><th>البائع</th><th>المجموع</th><th>الحالة</th><th></th></tr>
        ${sales.map(s => `<tr>
          <td class="num">${esc(s.invoice_no)}</td>
          <td class="num" style="font-size:12px;color:var(--sub)">${esc(s.created_at.slice(0, 16))}</td>
          <td>${esc(s.client_name || 'زبون عادي')}</td>
          <td>${esc(s.seller)}</td>
          <td class="num"><b>${dh(s.total)}</b></td>
          <td>${stChip(s.status)}</td>
          <td class="row-actions" style="white-space:nowrap">
            <button class="btn sm ghost" onclick="showInvoice(${s.id})">الفاتورة</button>
            ${s.status === 'completed' ? `<button class="btn sm danger" onclick="cancelSale(${s.id})">إلغاء</button>` : ''}
          </td></tr>`).join('') || '<tr><td colspan="7" class="empty">مازال ماكاينش مبيعات</td></tr>'}
      </table>
    </div>`;
}
async function cancelSale(id) {
  if (!confirm('متأكد بغيتي تلغي هاد البيع؟ الكمية غادي ترجع للمخزون.')) return;
  try { await api(`/sales/${id}/cancel`, { method: 'POST' }); renderSales(); }
  catch (e) { alert(e.message); }
}
async function showInvoice(id) {
  const s = await api(`/sales/${id}`);
  $('#invoiceBody').innerHTML = `
    <div class="invoice">
      <h1>أثاث نصيري — Ameublement Nassiri</h1>
      <div class="co">وجدة — تنجداد · الهاتف: 07 06 07 78 38 · ${esc(s.invoice_no)}</div>
      <table>
        <tr><th>المنتوج</th><th>الثمن</th><th>الكمية</th><th>المجموع</th></tr>
        ${s.items.map(i => `<tr><td>${esc(i.product_name)}</td><td class="num">${dh(i.price)}</td><td class="num">${i.qty}</td><td class="num">${dh(i.price * i.qty)}</td></tr>`).join('')}
      </table>
      <div class="totals"><b>المجموع الكلي: ${dh(s.total)}</b></div>
      <p class="co">الزبون: ${esc(s.client_name || 'زبون عادي')} · التاريخ: ${esc(s.created_at.slice(0, 16))} · البائع: ${esc(s.seller)} · الحالة: ${s.status === 'completed' ? 'مكتمل' : 'ملغي'}</p>
    </div>`;
  $('#invoiceModal').classList.remove('hidden');
}

// ---------- بيع جديد ----------
async function renderNewSale() {
  [PRODUCTS, CLIENTS] = [await api('/products'), await api('/clients')];
  CART = [];
  page.innerHTML = `
    <h2>بيع جديد</h2>
    <div class="sale-grid">
      <div class="panel">
        <h3>المنتوجات</h3>
        <input id="pSearch" placeholder="قلّب على منتوج..." style="width:100%;margin-bottom:12px">
        <div id="pList"></div>
      </div>
      <div class="total-box">
        <h3 style="margin-top:0">السلة</h3>
        <select id="cartClient" style="width:100%;margin-bottom:12px">
          <option value="">زبون عادي</option>
          ${CLIENTS.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}
        </select>
        <div id="cartList"><div class="empty">السلة خاوية</div></div>
        <hr style="border:none;border-top:1px solid var(--line)">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span>المجموع</span><span class="big num" id="cartTotal">0 DH</span>
        </div>
        <input id="saleNotes" placeholder="ملاحظات (اختياري)" style="width:100%;margin:12px 0">
        <button class="btn" id="confirmSale" style="width:100%">تأكيد البيع وفاتورة</button>
      </div>
    </div>`;
  drawPList('');
  $('#pSearch').oninput = e => drawPList(e.target.value);
  $('#confirmSale').onclick = confirmSale;
}
function drawPList(q) {
  const list = PRODUCTS.filter(p => p.name.includes(q) && p.stock > 0);
  $('#pList').innerHTML = list.map(p => `
    <div class="cart-line">
      <div style="flex:1"><b>${esc(p.name)}</b><br><small style="color:var(--sub)" class="num">${dh(p.price)} · باقي ${p.stock}</small></div>
      <input type="number" class="qty" id="q${p.id}" min="1" max="${p.stock}" value="1">
      <button class="btn sm" onclick="addToCart(${p.id})">زيد</button>
    </div>`).join('') || '<div class="empty">والو</div>';
}
function addToCart(pid) {
  const p = PRODUCTS.find(x => x.id === pid);
  const qty = Math.min(+$(`#q${pid}`).value || 1, p.stock);
  const ex = CART.find(l => l.product_id === pid);
  if (ex) ex.qty = Math.min(ex.qty + qty, p.stock); else CART.push({ product_id: pid, qty, name: p.name, price: p.price });
  drawCart();
}
function drawCart() {
  $('#cartList').innerHTML = CART.length ? CART.map((l, i) => `
    <div class="cart-line">
      <div style="flex:1">${esc(l.name)}<br><small class="num" style="color:var(--sub)">${dh(l.price)} × ${l.qty}</small></div>
      <b class="num">${dh(l.price * l.qty)}</b>
      <button class="btn sm ghost" onclick="CART.splice(${i},1);drawCart()">✕</button>
    </div>`).join('') : '<div class="empty">السلة خاوية</div>';
  $('#cartTotal').textContent = dh(CART.reduce((s, l) => s + l.price * l.qty, 0));
}
async function confirmSale() {
  if (!CART.length) return alert('السلة خاوية');
  try {
    const s = await api('/sales', { method: 'POST', body: { client_id: +$('#cartClient').value || null, items: CART.map(l => ({ product_id: l.product_id, qty: l.qty })), notes: $('#saleNotes').value } });
    await showInvoice(s.id);
    location.hash = 'sales';
  } catch (e) { alert(e.message); }
}

// ---------- المخزون ----------
async function renderProducts() {
  PRODUCTS = await api('/products');
  page.innerHTML = `
    <h2>المخزون</h2>
    <div class="panel">
      <form class="inline" id="pForm">
        <input id="pName" placeholder="سمية المنتوج" required>
        <input id="pPrice" type="number" min="0" placeholder="الثمن (DH)" required>
        <input id="pStock" type="number" min="0" placeholder="الكمية" required>
        <input id="pMin" type="number" min="0" placeholder="حد التنبيه" value="3">
        <button class="btn">زيد المنتوج</button>
      </form>
      <table>
        <tr><th>المنتوج</th><th>الثمن</th><th>المخزون</th><th>تباع</th><th></th></tr>
        ${PRODUCTS.map(p => `<tr>
          <td>${esc(p.name)}</td>
          <td class="num">${dh(p.price)}</td>
          <td><span class="chip num ${p.stock <= p.min_stock ? 'c-warn' : 'c-ok'}">${p.stock <= p.min_stock ? 'باقي ' : ''}${p.stock}</span></td>
          <td class="num">${p.sold}</td>
          <td class="row-actions" style="white-space:nowrap">
            <button class="btn sm ghost" onclick="editStock(${p.id})">تعديل</button>
            <button class="btn sm danger" onclick="delProduct(${p.id})">مسح</button>
          </td></tr>`).join('')}
      </table>
    </div>`;
  $('#pForm').onsubmit = async e => {
    e.preventDefault();
    try {
      await api('/products', { method: 'POST', body: { name: $('#pName').value, price: +$('#pPrice').value, stock: +$('#pStock').value, min_stock: +$('#pMin').value } });
      renderProducts();
    } catch (e2) { alert(e2.message); }
  };
}
async function editStock(id) {
  const p = PRODUCTS.find(x => x.id === id);
  const name = prompt('السمية:', p.name); if (name === null) return;
  const price = prompt('الثمن:', p.price); if (price === null) return;
  const stock = prompt('الكمية:', p.stock); if (stock === null) return;
  try { await api(`/products/${id}`, { method: 'PUT', body: { name, price: +price, stock: +stock, min_stock: p.min_stock } }); renderProducts(); }
  catch (e) { alert(e.message); }
}
async function delProduct(id) {
  if (!confirm('متأكد؟')) return;
  try { await api(`/products/${id}`, { method: 'DELETE' }); renderProducts(); }
  catch (e) { alert(e.message); }
}

// ---------- الزبائن ----------
async function renderClients() {
  CLIENTS = await api('/clients');
  page.innerHTML = `
    <h2>الزبائن</h2>
    <div class="panel">
      <form class="inline" id="cForm">
        <input id="cName" placeholder="السم الكامل" required>
        <input id="cPhone" placeholder="الهاتف">
        <input id="cAddr" placeholder="العنوان">
        <button class="btn">زيد الزبون</button>
      </form>
      <table>
        <tr><th>الاسم</th><th>الهاتف</th><th>العنوان</th><th>المشتريات</th><th>عدد العمليات</th><th></th></tr>
        ${CLIENTS.map(c => `<tr>
          <td>${esc(c.name)}</td><td class="num">${esc(c.phone)}</td><td>${esc(c.address)}</td>
          <td class="num"><b>${dh(c.total_spent)}</b></td><td class="num">${c.sales_count}</td>
          <td class="row-actions"><button class="btn sm danger" onclick="delClient(${c.id})">مسح</button></td></tr>`).join('') || '<tr><td colspan="6" class="empty">مازال ماكاينش زبائن</td></tr>'}
      </table>
    </div>`;
  $('#cForm').onsubmit = async e => {
    e.preventDefault();
    await api('/clients', { method: 'POST', body: { name: $('#cName').value, phone: $('#cPhone').value, address: $('#cAddr').value } });
    renderClients();
  };
}
async function delClient(id) {
  if (!confirm('متأكد؟ الفواتير ديالو غادي تبقى بلا زبون.')) return;
  await api(`/clients/${id}`, { method: 'DELETE' }); renderClients();
}

// ---------- التقارير ----------
async function renderReports() {
  const s = await api('/reports/summary');
  const months = ['يناير','فبراير','مارس','أبريل','ماي','يونيو','يوليو','غشت','شتنبر','أكتوبر','نونبر','دجنبر'];
  const m = new Date().getMonth();
  page.innerHTML = `
    <h2>التقارير</h2>
    <div class="grid">
      <div class="kpi"><small>مبيعات ${months[m]}</small><b class="num">${dh(s.month.t)}</b><small>${s.month.c} عملية</small></div>
      <div class="kpi"><small>مبيعات آخر 7 أيام</small><b class="num">${dh(s.week.t)}</b><small>${s.week.c} عملية</small></div>
      <div class="kpi"><small>مبيعات ملغية (30 يوم)</small><b class="num" style="color:var(--bad)">${s.cancelled.c}</b><small class="num">${dh(s.cancelled.t)}</small></div>
      <div class="kpi"><small>قيمة المخزون الحالي</small><b class="num">${dh(s.stockVal)}</b></div>
    </div>
    <div class="panel"><h3>تطور المبيعات اليومية (14 يوم)</h3>${barChart(s.daily)}</div>
    <div class="panel"><h3>أفضل 5 منتوجات بالقيمة</h3>
      ${s.top.length ? `<table><tr><th>#</th><th>المنتوج</th><th>الكمية</th><th>المجموع</th></tr>${s.top.map((t, i) => `<tr><td>${i + 1}</td><td>${esc(t.name)}</td><td class="num">${t.q}</td><td class="num"><b>${dh(t.t)}</b></td></tr>`).join('')}</table>` : '<div class="empty">مازال ماكاينش بيانات</div>'}
    </div>
    <div class="panel"><h3>المنتوجات اللي خاصها تعمر</h3>
      ${s.low.length ? `<table><tr><th>المنتوج</th><th>باقي</th><th>حد التنبيه</th></tr>${s.low.map(p => `<tr><td>${esc(p.name)}</td><td><span class="chip c-warn num">${p.stock}</span></td><td class="num">${p.min_stock}</td></tr>`).join('')}</table>` : '<div class="empty">كلشي مزيان</div>'}
    </div>`;
}

// ---------- المستعملين ----------
async function renderUsers() {
  const users = await api('/users');
  page.innerHTML = `
    <h2>المستعملين</h2>
    <div class="panel">
      <form class="inline" id="uForm">
        <input id="uName" placeholder="المستعمل" required>
        <input id="uPass" type="password" placeholder="كلمة السر" required>
        <select id="uRole"><option value="cashier">كاشير</option><option value="admin">مدير</option></select>
        <button class="btn">زيد المستعمل</button>
      </form>
      <table>
        <tr><th>المستعمل</th><th>الدور</th><th>تاريخ الإنشاء</th><th></th></tr>
        ${users.map(u => `<tr><td>${esc(u.username)}</td>
          <td>${u.role === 'admin' ? '<span class="chip c-warn">مدير</span>' : '<span class="chip c-ok">كاشير</span>'}</td>
          <td class="num" style="font-size:12px">${esc(u.created_at.slice(0, 10))}</td>
          <td class="row-actions"><button class="btn sm danger" onclick="delUser(${u.id})">مسح</button></td></tr>`).join('')}
      </table>
    </div>`;
  $('#uForm').onsubmit = async e => {
    e.preventDefault();
    try { await api('/users', { method: 'POST', body: { username: $('#uName').value, password: $('#uPass').value, role: $('#uRole').value } }); renderUsers(); }
    catch (e2) { alert(e2.message); }
  };
}
async function delUser(id) {
  if (!confirm('متأكد؟')) return;
  try { await api(`/users/${id}`, { method: 'DELETE' }); renderUsers(); }
  catch (e) { alert(e.message); }
}

// ---------- بداية ----------
(async () => {
  ME = await api('/me');
  if (ME) boot();
})();
