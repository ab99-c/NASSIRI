// server.js — سيرفر الـERP
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'nassiri-erp-change-me',
  resave: false, saveUninitialized: false, cookie: { maxAge: 1000*60*60*12 }
}));
app.use(express.static(path.join(__dirname, 'public')));

// ---------- الحماية ----------
function auth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: 'خاصك تكون مسجل الدخول' });
  next();
}
function adminOnly(req, res, next) {
  if (req.session.user?.role !== 'admin') return res.status(403).json({ error: 'هاد العملية خاصها صلاحية المدير' });
  next();
}

// ---------- الجلسة ----------
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE username = ?').get(String(username || '').trim());
  if (!u || !bcrypt.compareSync(String(password || ''), u.password_hash))
    return res.status(401).json({ error: 'المستعمل أو كلمة السر غالطين' });
  req.session.user = { id: u.id, username: u.username, role: u.role };
  res.json(req.session.user);
});
app.post('/api/logout', (req, res) => { req.session.destroy(() => res.json({ ok: true })); });
app.get('/api/me', (req, res) => res.json(req.session.user || null));

// ---------- المنتوجات ----------
app.get('/api/products', auth, (req, res) => {
  res.json(db.prepare(`SELECT p.*, COALESCE((SELECT SUM(si.qty) FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE si.product_id=p.id AND s.status='completed'),0) AS sold FROM products p ORDER BY p.id DESC`).all());
});
app.post('/api/products', auth, (req, res) => {
  const { name, price, stock, min_stock } = req.body || {};
  if (!name || !(price >= 0)) return res.status(400).json({ error: 'سمية والثمن ضروريين' });
  const r = db.prepare('INSERT INTO products (name, price, stock, min_stock) VALUES (?,?,?,?)')
    .run(String(name).trim(), +price, Math.max(0, +stock || 0), +min_stock || 3);
  res.json(db.prepare('SELECT * FROM products WHERE id=?').get(r.lastInsertRowid));
});
app.put('/api/products/:id', auth, (req, res) => {
  const { name, price, stock, min_stock } = req.body || {};
  db.prepare('UPDATE products SET name=?, price=?, stock=?, min_stock=? WHERE id=?')
    .run(String(name).trim(), +price, Math.max(0, +stock || 0), +min_stock || 3, req.params.id);
  res.json(db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id));
});
app.delete('/api/products/:id', auth, (req, res) => {
  const used = db.prepare('SELECT COUNT(*) c FROM sale_items WHERE product_id=?').get(req.params.id).c;
  if (used) return res.status(400).json({ error: 'مايمكنش تمسح منتوج عندو مبيعات — حيدو من البيع بدل التعديل' });
  db.prepare('DELETE FROM products WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- الزبائن ----------
app.get('/api/clients', auth, (req, res) => {
  res.json(db.prepare(`SELECT c.*, (SELECT COUNT(*) FROM sales s WHERE s.client_id=c.id AND s.status='completed') AS sales_count,
    (SELECT COALESCE(SUM(total),0) FROM sales s WHERE s.client_id=c.id AND s.status='completed') AS total_spent
    FROM clients c ORDER BY c.id DESC`).all());
});
app.post('/api/clients', auth, (req, res) => {
  const { name, phone, address } = req.body || {};
  if (!name) return res.status(400).json({ error: 'السم ضروري' });
  const r = db.prepare('INSERT INTO clients (name, phone, address) VALUES (?,?,?)')
    .run(String(name).trim(), String(phone || ''), String(address || ''));
  res.json(db.prepare('SELECT * FROM clients WHERE id=?').get(r.lastInsertRowid));
});
app.delete('/api/clients/:id', auth, (req, res) => {
  db.prepare('UPDATE sales SET client_id = NULL WHERE client_id = ?').run(req.params.id);
  db.prepare('DELETE FROM clients WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- المبيعات والفواتير ----------
// إنشاء بيع: كنقصو من المخزون داخل معاملة واحدة
app.post('/api/sales', auth, (req, res) => {
  const { client_id, items, notes } = req.body || {};
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'البيع خاصو يكون فيه منتوج واحد على الأقل' });
  const tx = db.transaction(() => {
    let total = 0;
    const lines = [];
    for (const it of items) {
      const p = db.prepare('SELECT * FROM products WHERE id=?').get(it.product_id);
      if (!p) throw new Error('منتوج ماشي موجود');
      if (p.stock < it.qty) throw new Error(`المخزون ما كايفيتش: "${p.name}" (باقي ${p.stock})`);
      total += p.price * it.qty;
      lines.push({ p, qty: it.qty });
    }
    const year = new Date().getFullYear();
    const last = db.prepare(`SELECT invoice_no FROM sales WHERE invoice_no LIKE 'FA-${year}-%' ORDER BY id DESC LIMIT 1`).get();
    const next = last ? parseInt(last.invoice_no.split('-')[2]) + 1 : 1;
    const invoice_no = `FA-${year}-${String(next).padStart(4, '0')}`;
    const r = db.prepare(`INSERT INTO sales (invoice_no, client_id, user_id, status, total, notes)
      VALUES (?,?,?,?,?,?)`).run(invoice_no, client_id || null, req.session.user.id, 'completed', total, String(notes || ''));
    const sid = r.lastInsertRowid;
    const si = db.prepare('INSERT INTO sale_items (sale_id, product_id, qty, price) VALUES (?,?,?,?)');
    const dec = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?');
    for (const l of lines) { si.run(sid, l.p.id, l.qty, l.p.price); dec.run(l.qty, l.p.id); }
    return sid;
  });
  try { const sid = tx(); res.json(getSale(sid)); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

// إلغاء بيع: كيرجع الكمية للمخزون
app.post('/api/sales/:id/cancel', auth, (req, res) => {
  const tx = db.transaction(() => {
    const s = db.prepare('SELECT * FROM sales WHERE id=?').get(req.params.id);
    if (!s) throw new Error('البيع ماشي موجود');
    if (s.status === 'cancelled') throw new Error('هاد البيع ملغي من قبل');
    const inc = db.prepare(`UPDATE products SET stock = stock + (SELECT qty FROM sale_items WHERE sale_id=? AND product_id=products.id)
      WHERE id IN (SELECT product_id FROM sale_items WHERE sale_id=?)`);
    inc.run(s.id, s.id);
    db.prepare(`UPDATE sales SET status='cancelled', cancelled_at=datetime('now'), cancelled_by=? WHERE id=?`)
      .run(req.session.user.id, s.id);
  });
  try { tx(); res.json(getSale(req.params.id)); }
  catch (e) { res.status(400).json({ error: e.message }); }
});

app.get('/api/sales', auth, (req, res) => {
  const { from, to, status } = req.query;
  let q = `SELECT s.*, c.name AS client_name, u.username AS seller FROM sales s
    LEFT JOIN clients c ON c.id=s.client_id LEFT JOIN users u ON u.id=s.user_id WHERE 1=1`;
  const args = [];
  if (status) { q += ' AND s.status=?'; args.push(status); }
  if (from) { q += ' AND date(s.created_at) >= ?'; args.push(from); }
  if (to) { q += ' AND date(s.created_at) <= ?'; args.push(to); }
  q += ' ORDER BY s.id DESC LIMIT 300';
  res.json(db.prepare(q).all(...args));
});
function getSale(id) {
  const s = db.prepare(`SELECT s.*, c.name AS client_name, c.phone AS client_phone, c.address AS client_address, u.username AS seller
    FROM sales s LEFT JOIN clients c ON c.id=s.client_id LEFT JOIN users u ON u.id=s.user_id WHERE s.id=?`).get(id);
  s.items = db.prepare(`SELECT si.*, p.name AS product_name FROM sale_items si JOIN products p ON p.id=si.product_id WHERE si.sale_id=?`).all(id);
  return s;
}
app.get('/api/sales/:id', auth, (req, res) => res.json(getSale(req.params.id)));

// ---------- التقارير ----------
app.get('/api/reports/summary', auth, (req, res) => {
  const today = db.prepare(`SELECT COALESCE(SUM(total),0) t, COUNT(*) c FROM sales WHERE status='completed' AND date(created_at)=date('now')`).get();
  const week = db.prepare(`SELECT COALESCE(SUM(total),0) t, COUNT(*) c FROM sales WHERE status='completed' AND created_at >= date('now','-7 days')`).get();
  const month = db.prepare(`SELECT COALESCE(SUM(total),0) t, COUNT(*) c FROM sales WHERE status='completed' AND strftime('%Y-%m',created_at)=strftime('%Y-%m','now')`).get();
  const stockVal = db.prepare('SELECT COALESCE(SUM(price*stock),0) v FROM products').get().v;
  const low = db.prepare('SELECT * FROM products WHERE stock <= min_stock ORDER BY stock').all();
  const unpaid = 0;
  const cancelled = db.prepare(`SELECT COALESCE(SUM(total),0) t, COUNT(*) c FROM sales WHERE status='cancelled' AND created_at >= date('now','-30 days')`).get();
  const daily = db.prepare(`SELECT date(created_at) d, SUM(total) t, COUNT(*) c FROM sales WHERE status='completed' AND created_at >= date('now','-14 days') GROUP BY date(created_at) ORDER BY d`).all();
  const top = db.prepare(`SELECT p.name, SUM(si.qty) q, SUM(si.qty*si.price) t FROM sale_items si
    JOIN sales s ON s.id=si.sale_id AND s.status='completed' JOIN products p ON p.id=si.product_id
    GROUP BY si.product_id ORDER BY t DESC LIMIT 5`).all();
  res.json({ today, week, month, stockVal, low, cancelled, daily, top, unpaid });
});

// ---------- المستعملين (المدير فقط) ----------
app.get('/api/users', adminOnly, (req, res) => {
  res.json(db.prepare('SELECT id, username, role, created_at FROM users ORDER BY id').all());
});
app.post('/api/users', adminOnly, (req, res) => {
  const { username, password, role } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'المستعمل وكلمة السر ضروريين' });
  if (db.prepare('SELECT 1 FROM users WHERE username=?').get(username)) return res.status(400).json({ error: 'هاد المستعمل كاين من قبل' });
  db.prepare('INSERT INTO users (username, password_hash, role) VALUES (?,?,?)')
    .run(String(username).trim(), bcrypt.hashSync(String(password), 10), role === 'admin' ? 'admin' : 'cashier');
  res.json({ ok: true });
});
app.delete('/api/users/:id', adminOnly, (req, res) => {
  if (+req.params.id === req.session.user.id) return res.status(400).json({ error: 'مايمكنش تمسح حسابك نتا' });
  db.prepare('DELETE FROM users WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

app.listen(PORT, () => console.log(`✅ ERP Nassiri خدام على http://localhost:${PORT}`));
